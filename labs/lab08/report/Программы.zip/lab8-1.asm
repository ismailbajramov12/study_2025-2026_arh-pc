%include 'in_out.asm'

SECTION .data
    msg1 db 'Введите N: ',0h

SECTION .bss
    N: resb 10

SECTION .text
    global _start
_start:

; --- Вывод сообщения 'Введите N: '
    mov eax,msg1
    call sprint

; --- Ввод 'N'
    mov ecx, N
    mov edx, 10
    call sread

; --- Преобразование 'N' из символа в число
    mov eax,N
    call atoi
    mov [N],eax

; --- Организация цикла
    mov ecx,[N]    ; Счетчик цикла, `ecx=N`
label:
    push ecx
    sub ecx,1
    mov [N],ecx
    mov eax,[N]
    call iprintLF  ; Вывод значения `N`
    pop ecx
    loop label     ; `ecx=ecx-1` и если `ecx` не '0'

call quit          ; выход из программы
