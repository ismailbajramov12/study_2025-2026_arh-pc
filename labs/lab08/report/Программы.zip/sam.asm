%include 'in_out.asm'

SECTION .data
func_msg db 'Функция: f(x)=6x+13', 0
result_msg db 'Результат: ', 0

SECTION .text
global _start

_start:
    ; Получаем количество аргументов
    pop ecx
    pop edx
    sub ecx, 1
    mov esi, 0      ; Сумма результатов функции

    ; Выводим сообщение о функции
    mov eax, func_msg
    call sprintLF

next:
    cmp ecx, 0
    jz _end
    
    ; Получаем аргумент и преобразуем в число
    pop eax
    call atoi
    
    ; Вычисляем f(x) = 6x + 13
    mov ebx, eax    ; сохраняем x в ebx
    imul eax, 6     ; eax = 6x
    add eax, 13     ; eax = 6x + 13
    
    ; Добавляем к общей сумме
    add esi, eax
    
    loop next

_end:
    ; Выводим результат
    mov eax, result_msg
    call sprint
    mov eax, esi
    call iprintLF
    
    call quit
